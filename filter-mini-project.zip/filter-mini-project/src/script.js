var image;
var canvasimage = null;

function upload() {
  canvasimage = document.getElementById("canv");
  var fileinput = document.getElementById("uploadImg");
  image = new SimpleImage(fileinput);
  image.drawTo(canvasimage);
}
canvasimage;
image;

function changeGray() {
  for (var pixel of image.values()) {
    var avg = (pixel.getRed() + pixel.getGreen() + pixel.getBlue()) / 3;
    pixel.setRed(avg);
    pixel.setGreen(avg);
    pixel.setBlue(avg);
  }

  var imgcanvas = document.getElementById("canv");
  image.drawTo(imgcanvas);
}

function changeFade() {
  for (var pixel of image.values()) {
    var avg = (pixel.getRed() + pixel.getGreen() + pixel.getBlue()) / 2;
    pixel.setRed(avg);
    pixel.setGreen(avg);
    pixel.setBlue(avg);
  }
  imgcanvas = document.getElementById("canv");
  image.drawTo(imgcanvas);
}

function changeRed() {
  for (var pixel of image.values()) {
    var avg = (pixel.getRed() + pixel.getGreen() + pixel.getBlue()) / 3;
    if (avg < 128) {
      pixel.setRed(2 * avg);
      pixel.setGreen(0);
      pixel.setBlue(0);
    } else {
      pixel.setRed(255);
      pixel.setGreen(2 * (avg - 255));
      pixel.setBlue(2 * (avg - 255));
    }
  }
  imgcanvas = document.getElementById("canv");
  image.drawTo(imgcanvas);
}

function changeBlue() {
  for (var pixel of image.values()) {
    var avg = (pixel.getRed() + pixel.getGreen() + pixel.getBlue()) / 3;
    if (avg < 128) {
      pixel.setBlue(2 * avg);
      pixel.setGreen(0);
      pixel.setRed(0);
    } else {
      pixel.setBlue(255);
      pixel.setGreen(2 * (avg - 255));
      pixel.setRed(2 * (avg - 255));
    }
  }
  imgcanvas = document.getElementById("canv");
  image.drawTo(imgcanvas);
}

function changeGreen() {
  for (var pixel of image.values()) {
    var avg = (pixel.getRed() + pixel.getGreen() + pixel.getBlue()) / 3;
    if (avg < 128) {
      pixel.setGreen(2 * avg);
      pixel.setRed(0);
      pixel.setBlue(0);
    } else {
      pixel.setGreen(255);
      pixel.setRed(2 * (avg - 255));
      pixel.setBlue(2 * (avg - 255));
    }
  }
  imgcanvas = document.getElementById("canv");
  image.drawTo(imgcanvas);
}

function onClear() {
  var fileinput = document.getElementById("uploadImg");
  image = new SimpleImage(fileinput);
  image.drawTo(canvasimage);
}

//
